package uta.cse3310.GameTermination;

/**
 * Represents the possible statuses of the game.
 */
public enum GameStatus {
    RED_WIN, BLACK_WIN, DRAW, ONGOING
}
