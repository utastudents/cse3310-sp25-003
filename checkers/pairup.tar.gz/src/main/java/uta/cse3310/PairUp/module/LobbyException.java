package uta.cse3310.PairUp.module;

/* pairup/exception/LobbyException.java */
public class LobbyException extends Exception {
    public LobbyException(String message) {
        super(message);
    }
}
