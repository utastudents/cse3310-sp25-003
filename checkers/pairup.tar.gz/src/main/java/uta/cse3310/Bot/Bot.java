package uta.cse3310.Bot;

public abstract class Bot {
    
}
