package uta.cse3310.PageManager;

public class game_status {
    public Integer turn;
    public Float score;
    public String message;
    public String gameID;
    public String opponent;
}

