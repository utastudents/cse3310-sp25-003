package uta.cse3310.PageManager;

import java.util.ArrayList;


public class UserEventReply {
    public game_status status;
    public ArrayList<Integer> recipients;
}
