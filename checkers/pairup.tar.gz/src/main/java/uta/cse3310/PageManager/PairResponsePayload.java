package uta.cse3310.PageManager;

public class PairResponsePayload {
    public String gameID;
    public String opponentHandle;
}

