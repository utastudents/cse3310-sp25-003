package uta.cse3310.PageManager;

public class UserEvent {
    public Integer id; // the user id that created the message
    String msg;

}
