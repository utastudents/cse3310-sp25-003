package uta.cse3310.DB;

public class MatchHistory {
    
    private int playerID;
    private String boardState;

    public int getplayerID(int playerID){

        return playerID;
    }

    public void setplayerID(int playerID){}

    public String getboardState(String playerID){

        return boardState;
    }

    public void setboardState(){}

    public void saveGame(){}

    public void loadGame(){}
}

