Interface Description

The database system will:
Store Player Accounts - username, email, password hash
Track Player Stats - wins, losses, draws, ranking

Store Ongoing Matches - player IDs, board state, turn history
Save and Load game progress for paused or disconnected games

Queue players for matchmaking based on rank

Maintain rankings based on ELO or win rate
Display top players and recent match history (maybe)

Store rules
Implement tie conditions
