package uta.cse3310.DB;

public class DB {

}
